# OTA Component

```
RUST_LOG=info cargo run --package ota-component
```